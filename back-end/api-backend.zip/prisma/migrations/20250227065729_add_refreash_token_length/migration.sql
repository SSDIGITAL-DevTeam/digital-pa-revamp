-- AlterTable
ALTER TABLE `role` MODIFY `refreshToken` TEXT NULL;
