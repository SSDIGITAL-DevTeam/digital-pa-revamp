-- AlterTable
ALTER TABLE `blog` MODIFY `content` TEXT NOT NULL;
